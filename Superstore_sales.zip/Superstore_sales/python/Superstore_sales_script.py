import pandas as pd
import numpy as np
from pandas import isnull
from pandas.core.dtypes.missing import isna_all
from sqlalchemy import create_engine


df = pd.read_csv(r"C:\my projects\Superstore_sales\data\Superstore_raw.csv")

# Standardize column names
df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_")

# Step 2: Replace '-' with '/' (standardize format)
df["order_date"] = df["order_date"].str.replace("-", "/", regex=False)
df["ship_date"] = df["ship_date"].str.replace("-", "/", regex=False)

# Step 3: Convert to datetime (US format first)
df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce", format="%m/%d/%Y")
df["ship_date"] = pd.to_datetime(df["ship_date"], errors="coerce", format="%m/%d/%Y")

# Step 4: Handle remaining nulls (try day-first format)
df["order_date"] = df["order_date"].fillna(pd.to_datetime(df["order_date"], errors="coerce", dayfirst=True))
df["ship_date"] = df["ship_date"].fillna(pd.to_datetime(df["ship_date"], errors="coerce", dayfirst=True))

#extract year and month
df["year"] = df["order_date"].dt.year
df["month"] = df["order_date"].dt.month

# calculate delivery days
df["delivery_days"] = (df["ship_date"] - df["order_date"]).dt.days

# Cleaned file convert to csv
df.to_csv(r"C:\my projects\Superstore_sales\data\cleaned_superstore.csv", index=False)

# Create connection
engine = create_engine("mysql+pymysql://root:Arun%40123@localhost:3306/superstore_sales")

# Upload to MySQL
df.to_sql(
    name="cleaned_sales",
    con=engine,
    if_exists="replace",
    index=False
)

print("✅ Data uploaded successfully!")
