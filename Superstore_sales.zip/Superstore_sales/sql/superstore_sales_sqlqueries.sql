-- Database name to be used 
use superstore_sales;

-- reflects whole dataset
SELECT * FROM superstore_sales.cleaned_sales;

-- Total Profit
select round(sum(profit),2) as total_profit from superstore_sales.cleaned_sales;

-- Top Product
select product_name, sum(sales) as top_product from superstore_sales.cleaned_sales
group by product_name
order by top_product desc
limit 1;

-- Total Sales
select round(sum(sales),2) as total_sales from superstore_sales.cleaned_sales;

-- Total Orders
select count(distinct order_id) as total_orders from superstore_sales.cleaned_sales;

-- Top Customer
select customer_name, sum(sales) as Top_Customer from superstore_sales.cleaned_sales
group by customer_name
order by Top_Customer desc
limit 1;

--  Total Sales by City
select city, sum(sales) as citywise_sales from superstore_sales.cleaned_sales
group by city
order by citywise_sales desc;

-- Revenue trend over time
select year, month, round(sum(sales),2) as monthly_sales from superstore_sales.cleaned_sales
group by year, month
order by year, month;

-- Total Sales by Year
select year, sum(sales) yearwise_sales from superstore_sales.cleaned_sales
group by year
order by yearwise_sales desc;

--  Total Sales by Category
select category, round(sum(sales),2) categorywise_sales from superstore_sales.cleaned_sales
group by category;

-- Total Sales by Region
select region, round(sum(sales),2) regionwise_sales from superstore_sales.cleaned_sales
group by region;

-- Top 5 Products
select product_name, sum(sales) as top_5_products from superstore_sales.cleaned_sales
group by product_name
order by top_5_products desc
limit 5;

-- Bottom 5 Products
select product_name, sum(sales) as bottom_5_products from superstore_sales.cleaned_sales
group by product_name
order by bottom_5_products asc
limit 5;

-- profit by city
select city, sum(profit) as citywise_profit from superstore_sales.cleaned_sales
group by city
order by citywise_profit desc;

-- profit by product name
select product_name, sum(profit) as productwise_profit from superstore_sales.cleaned_sales
group by product_name
order by productwise_profit desc;

-- Top 10 Customers
select customer_name, round(sum(sales),2) as top_10_customers from superstore_sales.cleaned_sales
group by customer_name
order by top_10_customers desc
limit 10;